#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include <string.h>

int main(int argc, char **argv)
{
    OperationType ret_value = check_operation_type(argv);

    if (ret_value == e_encode)
    {
        EncodeInfo enc_info;
        printf("\n**************** Encoding Started *******************\n");
        printf("\n");

        if (read_and_validate_encode_args(argv, &enc_info) == e_failure)
        {
            printf("\nError: Read and validate failed. Operation terminated!\n");
            return 1;
        }

        if (do_encoding(&enc_info) == e_failure)
        {
            printf("\nOopss! Error in encoding process.\n");
            return 1;
        }
        printf("\nOUTPUT : Encoding process completed!\n");
        printf("\n");

        fclose(enc_info.fptr_src_image);
        fclose(enc_info.fptr_stego_image);
    }
    else if (ret_value == e_decode)
    {
        DecodeInfo decodeinfo;

        printf("****************Decoding Started***************\n");
        if (read_and_validate_decode_args(argv, &decodeinfo) == e_failure)
        {
            printf("1\n");
            printf("\nError: Read and validate failed. Operation terminated!\n");
            return 1;
        }

        if (do_decoding(&decodeinfo) == e_failure)
        {
            printf("\nOopss! Error in decoding process.\n");
            return 1;
        }
        printf("\nDecoding process completed!\n");

        fclose(decodeinfo.fptr_stego_image);
    }

    else
    {
        printf("\n Invalid Operation\n");
    }
    return 0;
}