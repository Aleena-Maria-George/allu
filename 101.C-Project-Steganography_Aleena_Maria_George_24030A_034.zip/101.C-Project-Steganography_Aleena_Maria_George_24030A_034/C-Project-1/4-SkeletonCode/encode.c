#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Open files for encoding */
Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    if (encInfo->fptr_src_image == NULL)
    {
        perror("Error opening source BMP file.Try again !");
        return e_failure;
    }

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    if (encInfo->fptr_secret == NULL)
    {
        perror("Error opening secret file.Try again!");
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb");
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("Error creating stego image file.Try again !");
        fclose(encInfo->fptr_src_image);
        fclose(encInfo->fptr_secret);
        return e_failure;
    }

    return e_success;
}

/* Validate input arguments */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if (strstr(argv[2], ".bmp") == NULL)
    {
        fprintf(stderr, "Error: Source file must be a .bmp file\n");
        return e_failure;
    }
    encInfo->src_image_fname = strdup(argv[2]);

    if (strstr(argv[3], ".txt") == NULL)
    {
        fprintf(stderr, "Error: Secret file must be a .txt file\n");
        return e_failure;
    }
    encInfo->secret_fname = strdup(argv[3]);

    if (strstr(argv[4], ".bmp") == NULL)
    {
        fprintf(stderr, "Error: Output file must be a .bmp file\n");
        return e_failure;
    }
    encInfo->stego_image_fname= strdup(argv[4]);

    return e_success;
}

/* Check if image has enough capacity */
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);

    uint required_bits = (strlen(MAGIC_STRING) + encInfo->size_secret_file + MAX_FILE_SUFFIX + sizeof(int)) * 8;
    uint image_capacity_bits = encInfo->image_capacity * 8;

    if (image_capacity_bits >= required_bits)
    {
        //printf("Image has enough size\n");
        return e_success;
    }

    fprintf(stderr, "Error: Image capacity is insufficient for encoding.\n");
    return e_failure;
}

/* Get BMP image size */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    fseek(fptr_image, 18, SEEK_SET);
    fread(&width, sizeof(int), 1, fptr_image);
    fread(&height, sizeof(int), 1, fptr_image);
    return width * height * 3;                                                                      //
}

/* Get file size */
uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    uint size = ftell(fptr);
    rewind(fptr);
    return size;
}

/* Copy BMP header */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    rewind(fptr_src_image);
    char header[HEADER_FILE_SIZE];

    if (fread(header, HEADER_FILE_SIZE, 1, fptr_src_image) != 1)
    {
        perror("Error reading BMP header");
        return e_failure;
    }

    if (fwrite(header, HEADER_FILE_SIZE, 1, fptr_dest_image) != 1)
    {
        perror("Error writing BMP header");
        return e_failure;
    }

    return e_success;
}

/* Encode a byte to LSB */
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int i = 0; i < 8; i++)
    {
        int bit = (data & (1 << i)) >> i;
        image_buffer[i] = image_buffer[i] & (~1);
        image_buffer[i] = image_buffer[i] | bit;
    }
}

/* Encode data into image */
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buffer[MAX_IMAGE_BUF_SIZE];

    for (int i = 0; i < size; i++)
    {
        if (fread(buffer, MAX_IMAGE_BUF_SIZE, 1, fptr_src_image) != 1)
        {
            perror("Error reading image data");
            return e_failure;
        }

        if (encode_byte_to_lsb(data[i], buffer) == e_failure)
            return e_failure;

        if (fwrite(buffer, MAX_IMAGE_BUF_SIZE, 1, fptr_stego_image) != 1)
        {
            perror("Error writing encoded data to stego image");
            return e_failure;
        }
    }
    return e_success;
}

/* Encode magic string */
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    return encode_data_to_image((char *)magic_string, strlen(magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

/* Encode file extension */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    return encode_data_to_image((char *)file_extn, strlen(file_extn), encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

/* Encode secret file size */
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char buffer[4];
    for (int i = 0; i < 4; i++)
    {
        buffer[i] = (file_size >> (i * 8)) & 0xFF;
    }
    return encode_data_to_image(buffer, 4, encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

/* Encode secret file data */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char *file_data = malloc(encInfo->size_secret_file);
    if (file_data == NULL)
    {
        perror("Error allocating memory for secret file data");
        return e_failure;
    }

    if (fread(file_data, encInfo->size_secret_file, 1, encInfo->fptr_secret) != 1)
    {
        free(file_data);
        perror("Error reading secret file data");
        return e_failure;
    }

    Status result = encode_data_to_image(file_data, encInfo->size_secret_file, encInfo->fptr_src_image, encInfo->fptr_stego_image);
    free(file_data);

    return result;
}

/* Encoding process */
/* Do encoding */
Status do_encoding(EncodeInfo *encInfo)
{
    // Ensure that the files are opened successfully
    if (open_files(encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Files opened successfully\n");
    printf("\n");

    // Check capacity//
    if (check_capacity(encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : The source file capacity is suitable for encoding of data\n");
    printf("\n");
    // Copy header//
    if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : bmp header copied successfully\n");
    printf("\n");
    // Encoding operations//

    //magic string encoding//
    if (encode_magic_string(MAGIC_STRING, encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Magic string encoding successful\n");
    printf("\n");

    //encoding secret file extension//
    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Secret file extension encoding successfull\n"); 
    printf("\n");   

    //encoding secret file size//
    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Secret file size encoding successfull\n");   
    printf("\n");     

    //encoding secret file data//
    if (encode_secret_file_data(encInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Secret file data encoding successfull\n");  
    printf("\n");      

    // Copy remaining image data
    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Copying of remaining data successfull\n");
    printf("\n");
    return e_success;
}


/* Copy remaining BMP data */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char buffer[1024];
    size_t bytes_read;

    while ((bytes_read = fread(buffer, 1, sizeof(buffer), fptr_src)) > 0)
    {
        if (fwrite(buffer, 1, bytes_read, fptr_dest) != bytes_read)
        {
            perror("Error writing remaining image data");
            return e_failure;
        }
    }

    if (bytes_read == 0) {
        printf("INFO : Finished copying image data.\n");
        printf("\n");
    } else {
        perror("Error reading image data");
        return e_failure;
    }

    return e_success;
}


OperationType check_operation_type(char *argv[])
    {
        if((strcmp(argv[1],"-e")) == 0)
        {
            return e_encode;
        }
        else if((strcmp(argv[1],"-d")) == 0)
        {
            return e_decode;
        }
        else
        {
            return e_unsupported;
        }
    }





















