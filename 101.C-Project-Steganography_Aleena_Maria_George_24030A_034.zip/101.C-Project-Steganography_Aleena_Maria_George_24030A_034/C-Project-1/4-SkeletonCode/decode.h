#ifndef DECODE_H
#define DECODE_H

#include "types.h"
#include "common.h"

#define DECODE_IMAGE_BUF_SIZE 8
#define DECODE_FILE_SUFFIX 10

typedef struct DecodeInfo
{
    char *secret_decoded_fname;
    FILE *fptr_secret_decoded;
    char extn_secret_file[DECODE_FILE_SUFFIX];
    long size_secret_file;

    char *stego_image_fname;
    FILE *fptr_stego_image;

} DecodeInfo;

/* Function prototypes */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decodeInfo);


Status do_decoding(DecodeInfo *decodeInfo);


Status open_files_decode(DecodeInfo *decodeInfo);


Status decode_magic_string(DecodeInfo *decodeInfo);


Status decode_secret_file_extn(DecodeInfo *decodeInfo);


Status decode_secret_file_size(DecodeInfo *decodeInfo);


Status decode_secret_file_data(DecodeInfo *decodeInfo);


Status decode_data_from_image(char *data, int size, FILE *fptr_stego_image);


char decode_lsb_to_byte(char *image_buffer);

#endif