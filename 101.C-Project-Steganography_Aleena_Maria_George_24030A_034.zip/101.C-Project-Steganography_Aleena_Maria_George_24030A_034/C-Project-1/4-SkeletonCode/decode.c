#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"

/* Open files for decoding */
Status open_files_decode(DecodeInfo *decodeInfo)
{
    decodeInfo->fptr_stego_image = fopen(decodeInfo->stego_image_fname, "rb");
    if (decodeInfo->fptr_stego_image == NULL)
    {
        perror("Error opening stego BMP file");
        return e_failure;
    }

    decodeInfo->fptr_secret_decoded = fopen(decodeInfo->secret_decoded_fname, "w");
    if (decodeInfo->fptr_secret_decoded == NULL)
    {
        perror("Error creating output file");
        fclose(decodeInfo->fptr_stego_image);
        return e_failure;
    }

    return e_success;
}

/* Read and validate decoding arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decodeInfo)
{
    if (argv[2] == NULL || strstr(argv[2], ".bmp") == NULL)
    {
        fprintf(stderr, "Error: Source file must be a .bmp file\n");
        return e_failure;
    }
    decodeInfo->stego_image_fname = strdup(argv[2]);

    decodeInfo->secret_decoded_fname = (argv[3] != NULL) ? strdup(argv[3]) : strdup("decoded_secret.txt");

    return e_success;
}

/* Extract a byte from LSB */
char decode_lsb_to_byte(char *image_buffer)
{
    char data = 0;
    //printf("Extracted bits: ");

    for (int i = 0; i < 8; i++)
    {
        int bit = (image_buffer[i] & 1);  // Extract LSB
        data |= (bit << i);               // Use the order LSB first
        //printf("%d", bit);
    }

    printf(" -> Byte: %c (%d)\n", data, data);
    return data;
}



/* Decode data from image */
Status decode_data_from_image(char *data, int size, FILE *fptr_stego_image)
{
    char buffer[8];

    for (int i = 0; i < size; i++)
    {
        if (fread(buffer, sizeof(char), 8, fptr_stego_image) != 8)
        {
            perror("Error reading image data");
            return e_failure;
        }
        data[i] = decode_lsb_to_byte(buffer);
    }
    return e_success;
}

/* Decode magic string */
Status decode_magic_string(DecodeInfo *decodeInfo)
{
    fseek(decodeInfo->fptr_stego_image, 54, SEEK_SET);  // Skip BMP header

    char extracted_magic[strlen(MAGIC_STRING) + 1];

    if (decode_data_from_image(extracted_magic, strlen(MAGIC_STRING), decodeInfo->fptr_stego_image) == e_failure)
    {
        return e_failure;
    }

    extracted_magic[strlen(MAGIC_STRING)] = '\0';  // Null-terminate for safety

    printf("Extracted Magic String: [%s]\n", extracted_magic);

    if (strcmp(extracted_magic, MAGIC_STRING) != 0)
    {
        printf("Magic string mismatch. Expected: [%s], Found: [%s]\n", MAGIC_STRING, extracted_magic);
        return e_failure;
    }

    return e_success;
}

/* Decode secret file extension */
Status decode_secret_file_extn(DecodeInfo *encInfo)
{
    // Calculate the number of bytes to read (based on the extension length)
    int extn_len = strlen(MAGIC_STRING) +4;
    char *file_extn = malloc(extn_len + 1);  // Allocate space for the extension and null terminator
    if (file_extn == NULL)
    {
        perror("Error allocating memory for file extension");
        return e_failure;
    }

    // Read the file extension from the stego image
    Status result = decode_data_from_image(file_extn, extn_len, encInfo->fptr_stego_image);
    if (result == e_failure)
    {
        free(file_extn);
        return e_failure;
    }

    // Null-terminate the string
    file_extn[extn_len] = '\0';

    // Output the decoded file extension
    //printf("Decoded file extension: %s\n", file_extn);

    // Store or use the decoded file extension as needed
   
    free(file_extn);                            // Free the allocated memory
    return e_success;
}

/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decodeInfo)
{
    char buffer[4];
    if (decode_data_from_image(buffer, 4, decodeInfo->fptr_stego_image) == e_failure)
    {
        return e_failure;
    }

    decodeInfo->size_secret_file = 0;
    for (int i = 0; i < 4; i++)
    {
        decodeInfo->size_secret_file |= ((unsigned char)buffer[i] << (i * 8));
    }

    return e_success;
}

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decodeInfo)
{
    char *file_data = malloc(decodeInfo->size_secret_file);
    if (file_data == NULL)
    {
        perror("Error allocating memory for secret file data");
        return e_failure;
    }

    if (decode_data_from_image(file_data, decodeInfo->size_secret_file, decodeInfo->fptr_stego_image) == e_failure)
    {
        free(file_data);
        return e_failure;
    }

    

    fwrite(file_data, 1, decodeInfo->size_secret_file, decodeInfo->fptr_secret_decoded);
    free(file_data);

    return e_success;
}

/* Perform decoding */
Status do_decoding(DecodeInfo *decodeInfo)
{
    if (open_files_decode(decodeInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Files opened successfully\n");
    printf("\n");

    if (decode_magic_string(decodeInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Magic string decoded successfully\n");
    printf("\n");

    if (decode_secret_file_extn(decodeInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Secret file extension decoded successfully\n");
    printf("\n");

    if (decode_secret_file_size(decodeInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Secret file size decoded successfully\n");
    printf("\n");

    if (decode_secret_file_data(decodeInfo) == e_failure)
    {
        return e_failure;
    }
    printf("INFO : Secret file data decoded successfully\n");
    printf("\n");

    return e_success;
}