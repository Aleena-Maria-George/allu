#include "edit.h"
#include <string.h>

Status read_and_validate_edit_args(char **argv, Tag_Edit *tag)
{
    printf("Edit arguments validated\n");

    if (argv[2] == NULL)
    {
        printf("INFO: Usage -> ./mp3_tag_reader -e <modifier> \"New_Value\" <file_name.mp3>\n");
        return failure;
    }

    // Map user input to frame IDs
    if (strcmp(argv[2], "-t") == 0)
        strcpy(tag->Frame_ID, "TIT2");
    else if (strcmp(argv[2], "-A") == 0)
        strcpy(tag->Frame_ID, "TPE1");
    else if (strcmp(argv[2], "-a") == 0)
        strcpy(tag->Frame_ID, "TALB");
    else if (strcmp(argv[2], "-y") == 0)
        strcpy(tag->Frame_ID, "TYER");
    else if (strcmp(argv[2], "-G") == 0)
        strcpy(tag->Frame_ID, "TCON");
    else if (strcmp(argv[2], "-c") == 0)
        strcpy(tag->Frame_ID, "COMM");
    else
    {
        printf("Unsupported argument.\n");
        printf("Available arguments:\n");
        printf("-t  Modify Title\n-A  Modify Artist\n-a  Modify Album\n-y  Modify Year\n-G  Modify Genre\n-c  Modify Comments\n");
        return failure;
    }

    printf("Editing Frame ID: %s\n", tag->Frame_ID);

    if (argv[3] == NULL)
    {
        printf("INFO: Missing new value for %s.\n", tag->Frame_ID);
        printf("Usage -> ./mp3_tag_reader -e <modifier> \"New_Value\" <file_name.mp3>\n");
        return failure;
    }
    
    tag->size_new_data = strlen(argv[3]) + 1;
    tag->new_frame_data = argv[3];

    printf("New Data for %s: %s (Size: %d)\n", tag->Frame_ID, tag->new_frame_data, tag->size_new_data);

    if (argv[4] == NULL)
    {
        printf("INFO: Missing MP3 file.\n");
        printf("Usage -> ./mp3_tag_reader -e <modifier> \"New_Value\" <file_name.mp3>\n");
        return failure;
    }

    tag->fptr_mp3_edit = fopen(argv[4], "r");
    if (tag->fptr_mp3_edit == NULL)
    {
        printf("Error: Could not open file %s\n", argv[4]);
        return failure;
    }

    char str[3];
    fread(str, 1, 3, tag->fptr_mp3_edit);
    if (strncmp(str, "ID3", 3) == 0)
    {
        printf("MP3 Version: ID3v2.3\n");
    }
    else
    {
        printf("Error: Not a valid MP3 file.\n");
        return failure;
    }

    return success;
}

Status edit_tag(Tag_Edit *tag)
{
    tag->fptr_temp = fopen("temp.mp3", "wb");
    
    // Copy header
    char str[10];
    fread(str, 1, 10, tag->fptr_mp3_edit);
    fwrite(str, 1, 10, tag->fptr_temp);

    char *frame_tags[6] = {"TIT2", "TPE1", "TALB", "TYER", "TCON", "COMM"};

    for (int i = 0; i < 6; i++)
    {
        fread(str, 1, 4, tag->fptr_mp3_edit);
        fwrite(str, 1, 4, tag->fptr_temp);

        if (strncmp(tag->Frame_ID, frame_tags[i], 4) == 0)
        {
            printf("\nUpdated Frame: %s\n", tag->Frame_ID);
            if (copy_data(tag, 1) == failure)
                return failure;
        }
        else
        {
            if (copy_data(tag, 0) == failure)
                return failure;
        }
    }

    copy_remaining_data(tag);
    return success;
}

Status copy_data(Tag_Edit *tag, int flag)
{
    uint old_size, new_size;

    if (flag)
    {
        fread(&old_size, 4, 1, tag->fptr_mp3_edit);
        new_size = tag->size_new_data - 1;
        fwrite(&new_size, 4, 1, tag->fptr_temp);

        char str[3];
        fread(str, 1, 3, tag->fptr_mp3_edit);
        fwrite(str, 1, 3, tag->fptr_temp);

        fwrite(tag->new_frame_data, 1, new_size, tag->fptr_temp);
        fseek(tag->fptr_mp3_edit, old_size - 1, SEEK_CUR);
    }
    else
    {
        fread(&old_size, 4, 1, tag->fptr_mp3_edit);
        fwrite(&old_size, 4, 1, tag->fptr_temp);

        char str[100];
        fread(str, 1, 3, tag->fptr_mp3_edit);
        fwrite(str, 1, 3, tag->fptr_temp);

        fread(str, 1, old_size - 1, tag->fptr_mp3_edit);
        fwrite(str, 1, old_size - 1, tag->fptr_temp);
    }

    return success;
}

Status copy_remaining_data(Tag_Edit *tag)
{
    char ch;
    while ((ch = fgetc(tag->fptr_mp3_edit)) != EOF)
    {
        fputc(ch, tag->fptr_temp);
    }

    return success;
}
