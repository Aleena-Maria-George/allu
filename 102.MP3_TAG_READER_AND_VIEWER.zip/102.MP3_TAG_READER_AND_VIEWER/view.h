#ifndef VIEW_H
#define VIEW_H

#include "types.h"
#include <stdio.h>


/* Structure for storing tag information */
typedef struct
{
    FILE *fptr_mp3;
    uint tag_size;
    char * tag_data;
}Tag;


/* checks whether the given arguments are right or not*/
Status read_and_validate(char **argv,Tag *tag);

/* function to view the tags */
Status view_data(Tag *tag);

/* function to display the contents in the tag*/
Status display(Tag * tag);

/* to find out the opreration type */
Status check_operation_type(char ** argv);

/* help function */
void help();


#endif
