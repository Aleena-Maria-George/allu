#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "view.h"

#define HEADER_SIZE 10
#define FRAME_HEADER_SIZE 10

Status check_operation_type(char **argv)
{
    if (strcmp(argv[1], "--help") == 0)
    {
        help();
    }
    if (strcmp(argv[1], "-v") == 0)
    {
        return view;
    }
    else if (strcmp(argv[1], "-e") == 0)
    {
        return edit;
    }
    else
    {
        return unsupported;
    }
}

Status read_and_validate(char **argv, Tag *tag)
{
    /* error checking for format */
    if (argv[2] == NULL)
    {
        fprintf(stderr, "The format should be ./a.out <-v> <filename>\n");
        return failure;
    }
    else
    {
        tag->fptr_mp3 = fopen(argv[2], "rb");

        /* error checking for fopen */
        if (tag->fptr_mp3 == NULL)
        {
            perror("Error in opening the file!\n");
            return failure;
        }
        else
        {
            /* check for ID3 tag */
            char header[3];
            fread(header, 1, 3, tag->fptr_mp3);
            if (strncmp(header, "ID3", 3) == 0)
            {
                // printf("     ID3 Version ID: V2.3       \n");
                // printf("                                 \n");
            }
            else
            {
                printf("The file is not ID3\n");
                fclose(tag->fptr_mp3);
                return failure;
            }
        }
        rewind(tag->fptr_mp3);
    }
    return success;
}

Status view_data(Tag *tag)
{
    // Move file pointer to start of frames (skip ID3 header)
    fseek(tag->fptr_mp3, HEADER_SIZE, SEEK_SET);

    // Define an array of expected frame identifiers
    const char *frames[] = {"TIT2", "TALB", "TPE1", "TYER", "COMM", "TCON"};
    const char *labels[] = {"Title", "Album", "Artist", "Year", "Music", "Comment"};

   

    // Iterate through each frame type and try to read its data
    for (int i = 0; i < 6; i++)
    {
        printf("* %s   : ", labels[i]);
        if (display(tag) == failure)
        {
            printf("INFO: %s cannot be displayed\n", labels[i]);
        }
    }

    fclose(tag->fptr_mp3);
    return success;
}


Status display(Tag *tag)                    //reads and displays single tag
{
    char frame[5] = {0};
    if (fread(frame, 1, 4, tag->fptr_mp3) == 0)
    {
        return failure;
    }

    frame[4] = '\0'; // null termination
   // printf(" * %s : ", frame); // Print tag name 

    /* Read frame size in next 4 bytes */
    if (fread(&tag->tag_size, 4, 1, tag->fptr_mp3) == 0)
    {
        return failure;
    }

    /* Big Endian to Little Endian */
    char *pos = (char *)(&tag->tag_size);
    for (int i = 0; i < ((sizeof(uint)) / 2); i++)
    {
        pos[i] = pos[i] ^ pos[(sizeof(uint)) - i - 1];
        pos[(sizeof(uint)) - i - 1] = pos[i] ^ pos[(sizeof(uint)) - i - 1];
        pos[i] = pos[i] ^ pos[(sizeof(uint)) - i - 1];
    }

    /* Skip flag byte (3 extra bytes) */
    if (fseek(tag->fptr_mp3, 3, SEEK_CUR) != 0)
    {
        return failure;
    }

    /* Allocate memory for tag data */
    tag->tag_data = (char *)malloc(tag->tag_size);
    if (tag->tag_data == NULL)
    {
        perror("Memory allocation failed");
        return failure;
    }

    /* prints tag data chara by chara */
    if (fread(tag->tag_data, 1, tag->tag_size - 1, tag->fptr_mp3) != tag->tag_size - 1)
    {
        free(tag->tag_data);
        return failure;
    }

    /* Print tag data */
    for (int i = 0; i < tag->tag_size - 1; i++)
    {
        printf("%c", tag->tag_data[i]);
    }
    printf("\n");

    /* Free allocated memory */
    free(tag->tag_data);

    return success;
}



void help()
{
    printf("-----------------------------HELP MENU-------------------------------\n");
    printf("1. -v           -> to view mp3 file contents\n");
    printf("2. -e           -> to edit mp3 file contents\n");
    printf("        2.1. -t -> to edit song title\n");
    printf("        2.2. -a -> to edit artist name\n");
    printf("        2.3. -A -> to edit album name\n");
    printf("        2.4. -y -> to edit year\n");
    printf("        2.5. -t -> to edit content\n");
    printf("        2.6. -t -> to edit comment\n");
    printf("3. --help       -> to view the help option\n");
    printf("---------------------------------------------------------------------\n");

    
}