#include<stdio.h>
#include "types.h"
#include "view.h"
#include "edit.h"

int main(int argc, char **argv)
{
    Tag tag;
    Tag_Edit tag_edit;
    if(argc)
    {
        
        if(check_operation_type(argv)==view)
        {
            printf("------------------------------------------------------------\n");
            printf("----- -----------MP3 TAG VIWER AND EDITOR ------------------\n");
            printf("------------------------------------------------------------\n");
            if(read_and_validate(argv,&tag)==success);
            {
                //printf("read and validate succesfull \n ");
                if(view_data(&tag)==success)
                {
                    printf("------------------------------------------------------------\n");
                    printf("INFO : THE TAGS ARE PRINTED! \n");
                    printf("------------------------------------------------------------\n");
                }
            }
        }
        else if(check_operation_type(argv)==edit)
        {
            printf("------------------------------------\n");
            printf("----- MP3 TAG VIEWER AND EDITOR -----");
            printf("------------------------------------\n");
            if(read_and_validate_edit_args(argv,&tag_edit)==success);
            {
                if(edit_tag(&tag_edit)==success);
                printf("INFO : EDITING DONE! \n");
            }

        }
        else 
        {
             printf("operation not supported \n ");
        }
    }
    
}